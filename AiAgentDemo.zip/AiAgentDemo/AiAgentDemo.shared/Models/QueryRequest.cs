﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AiAgentDemo.shared.Models
{
    public class QueryRequest
    {
        public string NaturalQuery { get; set; } = string.Empty;
    }
}
