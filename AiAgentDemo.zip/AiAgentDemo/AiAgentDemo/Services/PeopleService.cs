﻿using AiAgentDemo.shared.Models;

namespace AiAgentDemo.Services
{
    public class PeopleService : IPeopleService
    {
        private readonly HttpClient _http;

        public PeopleService(HttpClient http)
        {
            _http = http;
        }

        public async Task<List<Person>> GetAllPeopleAsync()
        {
            return await _http.GetFromJsonAsync<List<Person>>("api/people");
        }

        public async Task<List<Person>> RunQueryAsync(string query)
        {
            var response = await _http.PostAsJsonAsync("api/query", new { NaturalQuery = query });

            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<List<Person>>();
            }
            else
            {
                // Read the error payload from the API
                var errorObj = await response.Content.ReadFromJsonAsync<Dictionary<string, string>>();
                var errorMessage = errorObj?["error"] ?? "Unknown error occurred.";
                throw new InvalidOperationException(errorMessage);
            }
        }

    }
}
