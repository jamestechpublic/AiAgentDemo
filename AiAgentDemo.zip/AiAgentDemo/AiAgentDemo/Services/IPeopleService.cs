﻿using AiAgentDemo.shared.Models;

namespace AiAgentDemo.Services
{
    public interface IPeopleService
    {
        Task<List<Person>> GetAllPeopleAsync();
        Task<List<Person>> RunQueryAsync(string query);
    }
}
