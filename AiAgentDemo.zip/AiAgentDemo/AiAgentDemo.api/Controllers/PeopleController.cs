﻿using AiAgentDemo.api.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AiAgentDemo.api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PeopleController : ControllerBase
    {
        IPeopleService _service;

        public PeopleController(IPeopleService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllPeople()
        {
            var people = await _service.GetAllPeople();
            return Ok(people);
        }

        //[HttpGet("{id}")]
        //public async Task<IActionResult> GetPersonById(int id)
        //{
        //    var person = await _service.GetPersonById(id);
        //    if (person == null)
        //        return NotFound();
        //    return Ok(person);
        //}
    }
}
