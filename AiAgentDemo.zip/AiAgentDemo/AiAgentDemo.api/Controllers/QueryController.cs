﻿using AiAgentDemo.api.Services;
using AiAgentDemo.shared.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AiAgentDemo.api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QueryController : ControllerBase
    {
        private readonly OllamaService _ollama;
        private readonly IPeopleService _people;
        
        public QueryController(OllamaService ollama, IPeopleService people)
        {
            _ollama = ollama;
            _people = people;
        }

        [HttpPost]
        public async Task<IActionResult> RunQuery([FromBody] QueryRequest request)
        {
            try
            {
                _ollama.OllamaLog($"Received Prompt: {request.NaturalQuery}");
                var sql = await _ollama.GenerateSqlAsync(request.NaturalQuery);
                _ollama.OllamaLog($"SQL Statement: {sql}");
                
                var results = await _people.ExecuteSqlAsync(sql);
                return Ok(results);
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        //[HttpGet("ping")]
        //public IActionResult Ping() => Ok("QueryController is alive!");

    }
}
