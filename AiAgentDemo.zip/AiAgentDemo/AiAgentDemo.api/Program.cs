
using AiAgentDemo.api.Data;
using AiAgentDemo.api.Services;
using Microsoft.EntityFrameworkCore;

namespace AiAgentDemo.api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddControllers();
            // Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
            builder.Services.AddOpenApi();

            builder.Services.AddDbContext<MyAppContext>(options =>
                options.UseSqlite(builder.Configuration.GetConnectionString("DefaultConnection")));

            builder.Services.AddScoped<IPeopleService, PeopleService>();
            
            builder.Services.AddHttpClient<OllamaService>(client =>
            {
                client.BaseAddress = new Uri("http://localhost:11434/");
            });

            var app = builder.Build();

            //using (var scope = app.Services.CreateScope())
            //{
            //    var ctx = scope.ServiceProvider.GetService<MyAppContext>();
            //    Console.WriteLine(ctx != null ? "DbContext resolved!" : "DbContext missing!");
            //}

            // Run seeding once
            //using (var scope = app.Services.CreateScope())
            //{
            //    var services = scope.ServiceProvider;
            //    var context = services.GetRequiredService<MyAppContext>();
            //    var peopleService = services.GetRequiredService<IPeopleService>();

            //    // Only import if table is empty
            //    if (!context.People.Any())
            //    {
            //        peopleService.ImportPeople("people.csv");
            //    }
            //}

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.MapOpenApi();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
