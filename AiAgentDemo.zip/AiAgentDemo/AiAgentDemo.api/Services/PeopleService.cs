﻿using AiAgentDemo.api.Data;
using AiAgentDemo.shared.Models;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;

namespace AiAgentDemo.api.Services
{
    public class PeopleService : IPeopleService
    {
        MyAppContext db;

        public PeopleService(MyAppContext context)
        {
            db = context;
        }

        public async Task<List<Person>?> GetAllPeople()
        {
            return await db.People.ToListAsync();
        }

        public async Task<List<Person>> ExecuteSqlAsync(string sql)
        {
            sql = ValidateSql(sql);

            return await db.People.FromSqlRaw(sql).ToListAsync();
        }

        private string ValidateSql(string sql)
        {
            sql = sql.Trim();

            // 1. Only SELECT
            if (!sql.StartsWith("SELECT", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Only SELECT queries are permitted.");
            // 2. Must target Person table
            if (!sql.Contains("FROM Person", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Queries must target the Person table.");
            // 3. Normalize column names
            var columnMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
                            {
                                { "last_name", "LastName" },
                                { "first_name", "FirstName" },
                                { "age", "Age" },
                                { "gender", "Gender" }
                            };
            foreach (var kvp in columnMap)
            {
                sql = Regex.Replace(sql, $@"\b{kvp.Key}\b", kvp.Value, RegexOptions.IgnoreCase);
            }
            // 4. Block dangerous keywords
            var forbidden = new[] { "INSERT", "UPDATE", "DELETE", "DROP", "ALTER" };
            foreach (var word in forbidden)
            {
                if (Regex.IsMatch(sql, $@"\b{word}\b", RegexOptions.IgnoreCase))
                    throw new InvalidOperationException($"Forbidden keyword detected: {word}");
            }

            return sql;
        }


        public async Task ImportPeople(string csvPath)
        {
            List<Person> people = new List<Person>();

            foreach (var line in File.ReadAllLines(csvPath).Skip(1)) // skip header
            {
                var parts = line.Split(',');
                if (parts.Length != 4) continue;

                people.Add(new Person
                {
                    FirstName = parts[0].Trim(),
                    LastName = parts[1].Trim(),
                    Age = int.Parse(parts[2].Trim()),
                    Gender = parts[3].Trim()
                });
            }

            db.People.AddRange(people);
            db.SaveChanges();
        }

        public async Task<Person?> GetPersonById(int id)
        {
            return await db.People.FindAsync(id);
        }
    }
}
