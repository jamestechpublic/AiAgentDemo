﻿using AiAgentDemo.shared.Models;

namespace AiAgentDemo.api.Services
{
    public interface IPeopleService
    {
        Task ImportPeople(string csvPath);
        Task<List<Person>?> GetAllPeople();
        Task<Person?> GetPersonById(int id);
        Task<List<Person>> ExecuteSqlAsync(string sql);
    }
        
}
