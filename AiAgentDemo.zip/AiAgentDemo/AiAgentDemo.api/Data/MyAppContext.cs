﻿using AiAgentDemo.shared.Models;
using Microsoft.EntityFrameworkCore;

namespace AiAgentDemo.api.Data
{
    public class MyAppContext : DbContext
    {
        public DbSet<Person> People { get; set; }

        public MyAppContext(DbContextOptions<MyAppContext> options) : base(options) { }
        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Map Person entity to "Person" table
            modelBuilder.Entity<Person>().ToTable("Person");
        }
    }
}
